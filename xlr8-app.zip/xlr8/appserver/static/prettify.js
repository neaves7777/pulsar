require([
    'prettify',
    'css!contrib/google-code-prettify/prettify.css',
    'splunkjs/mvc/simplexml/ready!'
], function(prettify) {
    prettify();
});
