This example shows you how to move form elements into a related panel.
