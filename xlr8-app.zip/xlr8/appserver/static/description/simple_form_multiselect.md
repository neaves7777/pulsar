This example shows you how to include a multi-select input from the
Splunk Enterprise JavaScript stack, and how to change that input into a
valid search query.
