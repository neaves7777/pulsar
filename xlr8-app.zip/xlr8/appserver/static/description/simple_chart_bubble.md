Visualize three dimensions of your data
