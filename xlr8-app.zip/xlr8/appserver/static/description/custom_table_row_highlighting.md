This example shows you how to color table rows based on conditions
having multiple field values.
