This example shows you how to drilldown in the page and update the url.
This can be useful for bookmarking and sharing.
