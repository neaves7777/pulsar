This example shows you how to link to other pages from the single value
visualization.
