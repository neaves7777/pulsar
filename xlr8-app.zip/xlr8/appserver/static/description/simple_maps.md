This example shows you how to plot geographical data on integrated maps.
