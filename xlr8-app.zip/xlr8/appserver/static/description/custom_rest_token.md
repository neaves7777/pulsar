This example shows you how to set a dashboard token, which is specified
in a custom configuration file and retrieved using REST.

-   a custom configuration file `default/myconf.conf`
-   a custom setup screen to update a configuration option `default/setup.xml`

    [http://docs.splunk.com/Documentation/Splunk/6.0beta/AdvancedDev/SetupApp](http://docs.splunk.com/Documentation/Splunk/6.0beta/AdvancedDev/SetupApp)
-   the `confs/conf-{name}` REST endpoint to retrieve the configured value

    [http://docs.splunk.com/Documentation/Splunk/6.0beta/RESTAPI/RESTconfigurations](http://docs.splunk.com/Documentation/Splunk/6.0beta/RESTAPI/RESTconfigurations)

The option `example_sourcetype` in the stanza `[settings]` is fetched
from the REST endpoint and exposed as the `$sourcetype$` token.
