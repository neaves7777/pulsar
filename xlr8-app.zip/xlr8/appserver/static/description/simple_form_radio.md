This example shows you how to set search terms by populating a form with
one or more sets of radio buttons.

The first radio button set is populated statically in XML, and the
second radio button set is populated dynamically based on the results of
a populating search and uses prefix and suffix tags to formulate the
search substring.

Both sets of radio buttons have a default value of `*` and cause the
search to re-run whenever a new value is selected. The panel title
reflects the radio button selections through use of tokens.
