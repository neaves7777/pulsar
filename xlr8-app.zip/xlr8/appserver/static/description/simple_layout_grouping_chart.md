This example shows you how to group multiple charts, tables, html
panels, or events, aligning vertically.
