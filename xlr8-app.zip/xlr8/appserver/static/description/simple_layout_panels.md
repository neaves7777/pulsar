This example shows you how to organize similar content in a single row.
