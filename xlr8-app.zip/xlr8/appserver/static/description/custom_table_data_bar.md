This example shows you how to add icons and color table rows, based on
search results.
