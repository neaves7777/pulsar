This example shows you how to add data overlay modes (heatmap,
high/values) using the dashboard editor.
