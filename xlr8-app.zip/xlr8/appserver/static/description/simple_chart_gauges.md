Visualize individual numerical values with Splunk Gauges

* Marker Gauges
* Filler Gauges
* Radial Gauges

Change the colors and ranges to be shown:

    <option name="charting.chart.rangeValues">[0,"333333","666666","1000000"]</option>
    <option name="charting.gaugeColors">[0x6cb8ca,0x956e96,0x324969]</option>