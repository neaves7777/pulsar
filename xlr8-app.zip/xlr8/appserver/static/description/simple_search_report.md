This example shows you how to use a Splunk Enterprise Report to power
dashboard elements.
