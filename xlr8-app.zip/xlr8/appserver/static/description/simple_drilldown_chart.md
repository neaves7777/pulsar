This example shows you how to cick on chart content to discover the
underlying events.
