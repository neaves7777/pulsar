The simple HTML panel provides a way to include text in your dashboard.
This can be a useful way to document or clarify dashboard usage. The
source is HTML-formatted text.

As the examples show, you can include the HTML in two ways, and both can
be used in the same dashboard:

-   Write raw HTML text directly in the HTML panel element (right).
-   Import the contents of an HTML-formatted file (left).

