This example shows you how to include multiple checkbox selection in
your dashboard.
