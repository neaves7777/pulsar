This example shows you how to define a custom chart overlay, using D3.
