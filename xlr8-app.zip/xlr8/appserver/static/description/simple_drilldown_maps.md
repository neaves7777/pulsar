This example shows you how to toggle map drilldown on or off.
