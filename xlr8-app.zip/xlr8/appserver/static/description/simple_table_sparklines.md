This example shows you how to configure basic and advanced sparkline
formatting options.
