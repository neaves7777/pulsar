This example shows you how to insert icon sets based on a value
rangemap, for a customized single value element.
