This example shows you how to create multiple time pickers and move them
into their related panels.
