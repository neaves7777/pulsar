This example shows you how to add icons to table cells based on custom
conditions.
