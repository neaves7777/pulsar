This example shows you how to use JavaScript to set tokens in panel
titles, html panels, and for drilldown.
