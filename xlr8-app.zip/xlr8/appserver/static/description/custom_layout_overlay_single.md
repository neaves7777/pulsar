This example shows you how to display workflow status visually using an
image, and groups single value elements.
