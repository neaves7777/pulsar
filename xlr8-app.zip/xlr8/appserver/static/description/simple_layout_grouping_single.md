This example shows you how to group multiple single value elements,
aligning horizontally.
