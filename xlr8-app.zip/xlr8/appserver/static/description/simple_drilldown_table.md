This example shows you how to discover the underlying events by clicking
on table content.
