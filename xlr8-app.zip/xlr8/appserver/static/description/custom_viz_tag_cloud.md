This example shows you how to add search-driven, custom visualizations
to a dashboard, using JavaScript.
