The above example shows a simple bar chart.

The data itself highlights the break down of user agents making requests to the splunk instance(s).
