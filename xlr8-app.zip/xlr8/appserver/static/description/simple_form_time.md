This example shows you how to add a timerange picker to modify a search
time span.
