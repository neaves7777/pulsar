This example shows you how to toggle dashboard content using a list of
links.
