This example shows you how to set search terms by populating a form with
one or more dropdown options.

The first dropdown is populated statically in XML, and the second
dropdown is populated dynamically based on the results of a populating
search and uses prefix and suffix tags to formulate the search
substring.

Both sets of dropdowns have a default value of `*` and cause the search
to re-run whenever a new value is selected. The panel title reflects the
dropdown selections through the use of tokens.
