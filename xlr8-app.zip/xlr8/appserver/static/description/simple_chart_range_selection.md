This example shows how to use chart range selection to modify other content on the page.

By default chart range selection will zoom to the selection.  Modify this behavior by added <selection> element to the xml with an action <link>, <set>, or <unset>