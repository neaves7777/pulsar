This example shows you how to re-use custom visualizations across
different dashboards without using separate scripts.
