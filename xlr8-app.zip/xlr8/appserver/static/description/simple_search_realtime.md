This example shows you how to use a real-time search for continuous
trend updating.
