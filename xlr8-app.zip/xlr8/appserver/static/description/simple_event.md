Events permit you to visualize the raw data indexed by Splunk
Enterprise, and is most primitive data visualization.

The first example shows a simple event `list` of internal sourcetype 
metrics for the last seven days, in descending order.

The more selective example, uses the *fields* parameter to select the
metadata items to display, and displays the
results in tabular format by specifying the *option* parameter `type` of
`table`.

In **Edit** - **Edit Panels** click the editing icons to experiment with
the various event display properties.
