This example shows you how to display the customized annotations trend,
for single value element.
