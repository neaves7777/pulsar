This example shows you how to control the drilldown destination and
content by passing click information to a linked form.
