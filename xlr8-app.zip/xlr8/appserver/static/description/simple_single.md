This example demonstrates a single value element with basic drilldown
and rangemap configurations.
