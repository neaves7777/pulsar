This example shows you how to select parts of event field metadata to
narrow a search.
