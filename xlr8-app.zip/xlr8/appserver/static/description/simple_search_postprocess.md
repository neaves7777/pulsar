This example shows you how to use a post process query to further filter
a global search.
