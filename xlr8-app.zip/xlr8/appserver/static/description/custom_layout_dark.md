This example shows you how to apply page-level, custom stylesheets to
your dashboards. Particularly, how gain better visibility on overhead
monitors.
