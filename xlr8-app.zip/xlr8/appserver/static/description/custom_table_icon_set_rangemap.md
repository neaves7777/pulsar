This example shows you how to use Javascript and CSS in tables to
convert rangemap results into icons.
