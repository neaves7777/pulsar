This example shows you how to use a search query to power dashboard
elements.
