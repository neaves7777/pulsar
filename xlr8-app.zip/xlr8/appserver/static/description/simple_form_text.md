This example shows you how to set search terms by populating a form with
textbox input.
