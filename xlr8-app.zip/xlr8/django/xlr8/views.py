from django.contrib.auth.decorators import login_required
from splunkdj.decorators.render import render_to

@render_to('xlr8:home.html')
@login_required
def home(request):
    return {
        "message": "Hello World from xlr8!",
        "app_name": "xlr8"
    }